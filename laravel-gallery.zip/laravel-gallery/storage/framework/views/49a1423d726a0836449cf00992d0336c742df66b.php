
<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Edit Gallery</div>
				<div class="card-body">
					<form action="<?php echo e(route('galleryUpdate', $gallery->id)); ?>" method="POST" enctype="multipart/form-data">
						<?php echo e(csrf_field()); ?>

						<div class="row">
							<div class="col-md-6">
								<label for="title">Gallery Title</label>
								<input type="text" name="title" value="<?php echo e($gallery->title); ?>" class="form-control">
							</div>
							<div class="col-md-6">
								<label for="cover">Gallery Cover</label>
								<input type="file" name="cover" class="form-control">
								<input type="hidden" value="<?php echo e($gallery->cover); ?>" name="old_cover">
							</div>
						</div>
						<br>
						<div class="row">
							<div class="col-md-12">
								<label for="description">Gallery Description</label>
								<textarea name="description" rows="3" class="form-control"><?php echo e($gallery->description); ?></textarea>
							</div>
						</div>
						<br>
						<button class="btn btn-primary" type="submit">Update Gallery</button>
					</form>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-gallery\resources\views/galleries/galleryEdit.blade.php ENDPATH**/ ?>