<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header"><?php echo e(__('Galleries')); ?></div>

                <div class="card-body">
                    <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>

                    <div class="row justify-content-center">
                        <?php $__currentLoopData = $galleries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $galary): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-3">
                                <a href="<?php echo e(route('galleryShow', $galary->id)); ?>">
                                    <img src="<?php echo e(asset('galleries/' . $galary->cover)); ?>" alt="cover" id="image">
                                    <p class="text-center"><?php echo e($galary->title); ?></p>
                                </a>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>

                </div>
            </div>
        </div>
        <div class="col-md-3"> 
            <div class="card">
                <div class="card-header">Create New Gallery</div>
                <div class="card-body">
                    <a href="<?php echo e(route('galleryCreate')); ?>" class="btn btn-success btn-block">Create New Gallery</a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-gallery\resources\views/home.blade.php ENDPATH**/ ?>