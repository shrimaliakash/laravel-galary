
<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center">
		<div class="col-md-3">
			<div class="card">
				<div class="card-header">Actions</div>
				<div class="card-body">
					<a href="<?php echo e(route('photoCreate', $photo->id)); ?>" class="btn btn-success btn-block">Edit Photo</a>
					<br>
					<a href="<?php echo e(route('galleryDelete', $photo->id)); ?>" class="btn btn-danger btn-block">Delete Photo</a>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-header"><?php echo e($photo->title); ?></div>
				<div class="card-body">
					<div class="row">
						<div cass="col-md-12"><?php echo e($photo->description); ?></div>
					</div>
					<div class="row">
						<div cass="col-md-12">
							<img src="<?php echo e(asset('galleries/photos/' . $photo->photo)); ?>" alt="photo" width="100%">
						</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-gallery\resources\views/galleries/photos/photoShow.blade.php ENDPATH**/ ?>