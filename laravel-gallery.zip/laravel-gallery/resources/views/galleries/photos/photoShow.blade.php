@extends('layouts.app')
@section('content')
	<div class="row justify-content-center">
		<div class="col-md-3">
			<div class="card">
				<div class="card-header">Actions</div>
				<div class="card-body">
					<a href="{{route('photoCreate', $photo->id)}}" class="btn btn-success btn-block">Edit Photo</a>
					<br>
					<a href="{{route('galleryDelete', $photo->id)}}" class="btn btn-danger btn-block">Delete Photo</a>
				</div>
			</div>
		</div>
		<div class="col-md-6">
			<div class="card">
				<div class="card-header">{{$photo->title}}</div>
				<div class="card-body">
					<div class="row">
						<div cass="col-md-12">{{$photo->description}}</div>
					</div>
					<div class="row">
						<div cass="col-md-12">
							<img src="{{asset('galleries/photos/' . $photo->photo)}}" alt="photo" width="100%">
						</div>
				</div>
			</div>
		</div>
	</div>
@endsection