<?php $__env->startSection('content'); ?>
    <div class="jumbotorn">
        <h1>Welcome to the Laravel Photo Gallery</h1>
        <p>For using this photo gallery, you have to register yourself and after that login to be able to create galleries and upload photos.</p>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-gallery\resources\views/welcome.blade.php ENDPATH**/ ?>