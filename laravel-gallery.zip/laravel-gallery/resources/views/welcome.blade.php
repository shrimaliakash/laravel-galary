@extends('layouts.app')
@section('content')
    <div class="jumbotorn">
        <h1>Welcome to the Laravel Photo Gallery</h1>
        <p>For using this photo gallery, you have to register yourself and after that login to be able to create galleries and upload photos.</p>
    </div>
@endsection