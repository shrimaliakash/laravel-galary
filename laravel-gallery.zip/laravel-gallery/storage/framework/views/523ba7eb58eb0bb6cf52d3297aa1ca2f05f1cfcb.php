
<?php $__env->startSection('content'); ?>
	<div class="row justify-content-center">
		<div class="col-md-8">
			<div class="card">
				<div class="card-header">Photos</div>
				<div class="card-body">
					<p><?php echo e($gallery->description); ?></p>
				</div>
			</div>
		</div>
		<div class="col-md-3">
			<div class="card">
				<div class="card-header"><?php echo e($gallery->title); ?></div>
				<div class="card-body text-center">
					<img src="<?php echo e(asset('galleries/' . $gallery->cover)); ?>" alt="cover" width="100%">
					<br><br>
					<a href="<?php echo e(route('photoCreate', $gallery->id)); ?>" class="btn btn-success btn-block">Upload Photo</a>
					<br>
					<a href="<?php echo e(route('galleryEdit', $gallery->id)); ?>" class="btn btn-success btn-block">Edit Gallery</a>
					<br>
					<a href="<?php echo e(route('galleryDelete', $gallery->id)); ?>" class="btn btn-danger btn-block">Delete Gallery</a>
				</div>
			</div>
		</div>
		<div calss="col-md-8">
			<div class="card">
				<div class="card-header">Photos</div>
				<div class="card-body">
					<div class="row">
						<div cass="col-md-12">
							<p><?php echo e($gallery->description); ?></p>
						</div>
					</div>
					<div class="row">
						<?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-3">
								<a href="<?php echo e(route('photoShow', $photo->id)); ?>"><img src="<?php echo e(asset('galleries/photos/' . $photo->photo)); ?>" alt="photo" width="100%"></a>
							</div>	
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\laravel-gallery\resources\views/galleries/galleryShow.blade.php ENDPATH**/ ?>